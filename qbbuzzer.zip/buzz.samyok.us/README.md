# qbbuzzer
##Instructions
Go to the <a href="http://qbbuzzer.com">website</a> and have everyone in your party join the same room. Press the button that says BUZZ or press the spacebar to (you guessed it) buzz. You can manually clear it before the time runs out. The settings button displays (you guessed it again) the settings, where you can toggle various things.

## What
QBBuzzer is a free online buzzer system. It is a website so it should work cross-platform without any major compatibility issues (it should work on whatever device you want as long as it has an internet connection and a modern web browser). Nothing fancy...just a regular buzzer system. It tells you who buzzed and has lockout functionality. Yay!

## Why
We decided to create QBBuzzer for a couple reasons. The first of which is that we had 25 people practices with 1 functioning buzzer system (10 buzzers). We had to split up practices with one room slapbowling. It sucked. We wanted to make something to fix that.
The other reason we created this was to help lower the barrier to entry for quizbowl. Buzzer systems are expensive. With this site, starting a new team is hopefully easier because you don't have to buy/borrow buzzer systems. 
